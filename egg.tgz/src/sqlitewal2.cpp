// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Checkpoint WAL2\n", stdout);
  return lionss_run_workload("sqlitewal2");
}
