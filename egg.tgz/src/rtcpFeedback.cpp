// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Process RTCP feedback"); }
int main(){
  announce();
  return lionss_run_workload("rtcpFeedback");
}
