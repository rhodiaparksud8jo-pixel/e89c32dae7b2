// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Collapse UMI duplicates"); }
int main(){
  announce();
  return lionss_run_workload("umi_dedup");
}
