// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Apply mTLS policy\n", stdout);
  return lionss_run_workload("istio_mtls");
}
